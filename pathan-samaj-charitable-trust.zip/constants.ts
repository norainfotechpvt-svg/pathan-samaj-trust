
export const REGISTRATION_FEE = 34000;
export const MUSLIM_MALE_REGISTRATION_FEE = 9000;
export const STORAGE_KEY = 'pathan_samaj_trust_data';

export const COLORS = {
  primary: 'emerald-700',
  secondary: 'amber-600',
  accent: 'indigo-600',
  bg: 'slate-50'
};
