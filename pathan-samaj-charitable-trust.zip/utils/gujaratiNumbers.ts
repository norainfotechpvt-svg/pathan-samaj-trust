
export const formatCurrency = (num: number): string => {
  return new Intl.NumberFormat('en-IN').format(num);
};

export const numberToGujaratiWords = (num: number): string => {
  if (num === 0) return 'શૂન્ય';
  
  const units = ['', 'એક', 'બે', 'ત્રણ', 'ચાર', 'પાંચ', 'છ', 'સાત', 'આઠ', 'નવ', 'દસ', 'અગિયાર', 'બાર', 'તેર', 'ચૌદ', 'પંદર', 'સોળ', 'સત્તર', 'અઢાર', 'ઓગણીસ'];
  const tens = ['', '', 'વીસ', 'ત્રીસ', 'ચાલીસ', 'પચાસ', 'સાઠ', 'સિત્તર', 'એંસી', 'નેવું'];
  
  const convert = (n: number): string => {
    if (n < 20) return units[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + units[n % 10] : '');
    if (n < 1000) return units[Math.floor(n / 100)] + ' સો ' + (n % 100 !== 0 ? convert(n % 100) : '');
    if (n < 100000) return convert(Math.floor(n / 1000)) + ' હજાર ' + (n % 1000 !== 0 ? convert(n % 1000) : '');
    if (n < 10000000) return convert(Math.floor(n / 100000)) + ' લાખ ' + (n % 100000 !== 0 ? convert(n % 100000) : '');
    return n.toString(); // Fallback for extremely large numbers
  };

  return convert(num) + ' રૂપિયા પૂરા';
};
