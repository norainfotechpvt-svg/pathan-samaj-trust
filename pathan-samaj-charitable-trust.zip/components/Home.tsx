
import React from 'react';

interface HomeProps {
  onAction: (view: 'REGISTER' | 'DIRECTORY' | 'FUND' | 'DIKRI_YOJNA') => void;
  membersCount: number;
}

const Home: React.FC<HomeProps> = ({ onAction, membersCount }) => {
  return (
    <div className="space-y-6 compact-container">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-[1.5rem] bg-gradient-to-r from-emerald-700 via-emerald-800 to-indigo-900 text-white p-8 md:p-12 ios-shadow">
        <div className="relative z-10 max-w-2xl text-center md:text-left">
          <p className="text-sm md:text-base text-emerald-50/90 mb-6 font-normal leading-relaxed italic">
            "સેવા અને સાથ" ની આ સફરમાં આપનું સ્વાગત છે. 
            તમારી વિગતો અને ફોટો કાયમી ધોરણે સુરક્ષિત છે.
          </p>
          <div className="flex flex-wrap justify-center md:justify-start gap-3">
            <button 
              onClick={() => onAction('REGISTER')}
              className="bg-white text-emerald-800 font-bold px-7 py-3 rounded-xl shadow-lg hover:bg-emerald-50 transition transform hover:-translate-y-0.5 active:scale-95 text-sm flex items-center"
            >
              નવું રજિસ્ટ્રેશન
              <i className="fas fa-plus ml-2 text-xs"></i>
            </button>
            <button 
              onClick={() => onAction('DIRECTORY')}
              className="bg-white/10 border border-white/20 font-bold px-7 py-3 rounded-xl backdrop-blur-md hover:bg-white/20 transition transform hover:-translate-y-0.5 active:scale-95 text-sm"
            >
              યાદી તપાસો
            </button>
          </div>
        </div>
        <div className="absolute right-0 bottom-0 opacity-5 pointer-events-none transform translate-x-1/4 translate-y-1/4">
          <i className="fas fa-hand-sparkles text-[15rem]"></i>
        </div>
      </section>

      {/* Special Scheme Section: 1 Crore Dikri Yojna */}
      <section 
        onClick={() => onAction('DIKRI_YOJNA')}
        className="bg-gradient-to-r from-amber-500 to-amber-700 rounded-[1.5rem] p-6 md:p-10 text-white ios-shadow cursor-pointer transform transition hover:scale-[1.01] active:scale-95 border-4 border-amber-300 relative overflow-hidden group"
      >
        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-center md:text-left">
            <div className="inline-block bg-white/20 backdrop-blur-sm px-4 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest mb-3 border border-white/30">
              સીમિત ઓફર • માત્ર રજિસ્ટર્ડ સભ્યો માટે
            </div>
            <h2 className="text-3xl md:text-4xl font-extrabold italic mb-2 drop-shadow-md">પઠાન દીકરી યોજના</h2>
            <p className="text-amber-50 text-sm md:text-base font-semibold max-w-md">પટેલ સમાજની દીકરી જો મુસ્લિમ સમાજના છોકરા જોડે પરણે તો ૧ કરોડની સહાય.</p>
          </div>
          <div className="text-center md:text-right">
             <p className="text-[10px] font-bold text-amber-200 uppercase mb-1">કુલ સહાય રકમ</p>
             <h3 className="text-4xl md:text-6xl font-black drop-shadow-lg">૧ કરોડ ₹</h3>
             <button className="mt-4 bg-white text-amber-700 font-bold px-8 py-2.5 rounded-xl shadow-xl hover:bg-amber-50 transition text-xs uppercase tracking-widest">ફોર્મ ભરો</button>
          </div>
        </div>
        <i className="fas fa-gem absolute right-[-20px] top-[-20px] text-white opacity-10 text-[10rem] group-hover:rotate-12 transition-transform duration-700"></i>
      </section>

      {/* Stats Section */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-2xl ios-shadow border border-slate-100 flex items-center space-x-4 group transition">
          <div className="bg-emerald-50 p-3 rounded-xl group-hover:bg-emerald-600 group-hover:text-white transition duration-300">
            <i className="fas fa-users text-xl"></i>
          </div>
          <div>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-[9px] mb-0.5">કુલ સભ્યો</p>
            <h3 className="text-xl font-bold">{membersCount}</h3>
          </div>
        </div>
        <div className="bg-white p-5 rounded-2xl ios-shadow border border-slate-100 flex items-center space-x-4 group transition">
          <div className="bg-amber-50 p-3 rounded-xl group-hover:bg-amber-600 group-hover:text-white transition duration-300">
            <i className="fas fa-coins text-xl"></i>
          </div>
          <div>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-[9px] mb-0.5">રજિસ્ટ્રેશન ફી</p>
            <h3 className="text-xl font-bold">₹34,000</h3>
          </div>
        </div>
        <div className="bg-white p-5 rounded-2xl ios-shadow border border-slate-100 flex items-center space-x-4 group transition">
          <div className="bg-indigo-50 p-3 rounded-xl group-hover:bg-indigo-600 group-hover:text-white transition duration-300">
            <i className="fas fa-camera text-xl"></i>
          </div>
          <div>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-[9px] mb-0.5">પ્રોફાઇલ ફોટો</p>
            <h3 className="text-base font-bold">સેવ સુવિધા</h3>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
