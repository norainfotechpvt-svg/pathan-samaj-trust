
import React, { useState } from 'react';
import { Member } from '../types';
import { numberToGujaratiWords, formatCurrency } from '../utils/gujaratiNumbers';

interface DirectoryProps {
  members: Member[];
  onViewMember: (id: string) => void;
}

const Directory: React.FC<DirectoryProps> = ({ members, onViewMember }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchBy, setSearchBy] = useState<'NAME' | 'ID'>('NAME');

  const filteredMembers = members.filter(m => {
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    if (searchBy === 'NAME') {
      return m.fullName.toLowerCase().includes(term) || m.city.toLowerCase().includes(term);
    } else {
      return m.registrationNumber.toLowerCase().includes(term);
    }
  });

  return (
    <div className="space-y-4 compact-container">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-6 border-b border-slate-50 bg-slate-50/50">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-bold text-slate-800 italic">સભ્યોની સૂચિ</h2>
              <p className="text-slate-500 text-xs mt-0.5">કુલ {members.length} નોંધાયેલા સભ્યો</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex bg-slate-200/50 p-0.5 rounded-lg">
                <button onClick={() => setSearchBy('NAME')} className={`px-3 py-1 rounded-md text-[10px] font-bold uppercase transition ${searchBy === 'NAME' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}>નામ</button>
                <button onClick={() => setSearchBy('ID')} className={`px-3 py-1 rounded-md text-[10px] font-bold uppercase transition ${searchBy === 'ID' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}>નંબર</button>
              </div>
              <div className="relative">
                <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 text-[10px]"></i>
                <input 
                  value={searchTerm} 
                  onChange={(e) => setSearchTerm(e.target.value)} 
                  placeholder="Search English or ગુજરાતી..." 
                  className="pl-8 pr-4 py-1.5 border border-slate-200 rounded-xl w-full md:w-64 outline-none text-xs focus:ring-1 focus:ring-emerald-500" 
                />
              </div>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 text-slate-400 text-[9px] uppercase tracking-widest font-bold">
              <tr>
                <th className="px-6 py-3 border-b">નંબર</th>
                <th className="px-6 py-3 border-b">સભ્ય / વિગત</th>
                <th className="px-6 py-3 border-b">સ્થિતિ</th>
                <th className="px-6 py-3 border-b">જ્ઞાતિ</th>
                <th className="px-6 py-3 border-b text-center">એક્શન</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filteredMembers.length === 0 ? (
                <tr><td colSpan={5} className="px-6 py-16 text-center text-slate-300 italic">કોઈ સભ્ય મળ્યા નથી.</td></tr>
              ) : (
                filteredMembers.map((member) => (
                  <tr key={member.id} className="hover:bg-emerald-50/20 transition group">
                    <td className="px-6 py-3.5"><span className="bg-slate-50 text-slate-500 px-1.5 py-0.5 rounded font-mono text-[9px] font-bold">{member.registrationNumber}</span></td>
                    <td className="px-6 py-3.5">
                      <div className="flex items-center space-x-2.5">
                         <div className="w-10 h-10 rounded-lg bg-slate-100 overflow-hidden flex-shrink-0 border border-slate-100 shadow-sm">
                            {member.photo ? <img src={member.photo} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-slate-300"><i className="fas fa-user text-[10px]"></i></div>}
                         </div>
                         <div className="flex flex-col">
                            <span className="font-bold text-slate-800">{member.fullName}</span>
                            <div className="flex flex-col mt-0.5">
                               <span className="text-[8px] text-slate-400 font-bold uppercase">{member.city}</span>
                               <span className="text-[9px] text-emerald-600 font-bold italic mt-0.5">આવક: ₹{formatCurrency(member.annualIncome)} ({numberToGujaratiWords(member.annualIncome)})</span>
                            </div>
                         </div>
                      </div>
                    </td>
                    <td className="px-6 py-3.5 text-slate-500 font-bold uppercase text-[9px]">
                      {member.maritalStatus === 'MARRIED' ? 'પરિણીત' : 'અપરિણીત'}
                    </td>
                    <td className="px-6 py-3.5 text-slate-700 font-semibold">{member.subCaste}</td>
                    <td className="px-6 py-3.5 text-center">
                      <button onClick={() => onViewMember(member.id)} className="bg-emerald-50 text-emerald-700 hover:bg-emerald-700 hover:text-white px-4 py-1.5 rounded-lg text-[9px] font-bold transition shadow-sm">જોવો</button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Directory;
