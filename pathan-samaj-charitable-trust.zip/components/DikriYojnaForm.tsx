
import React, { useState, useMemo } from 'react';
import { Member, Donation } from '../types';
import { formatCurrency, numberToGujaratiWords } from '../utils/gujaratiNumbers';

interface DikriYojnaFormProps {
  members: Member[];
  onClaim: (donation: Donation) => void;
  onCancel: () => void;
}

const DikriYojnaForm: React.FC<DikriYojnaFormProps> = ({ members, onClaim, onCancel }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState('');
  const [formData, setFormData] = useState({
    husbandName: '',
    wifeAge: '',
    husbandAge: '',
    wifeEducation: '',
    husbandEducation: '',
    wifeIncome: '',
    husbandIncome: '',
  });

  const selectedMember = useMemo(() => 
    members.find(m => m.id === selectedMemberId), 
  [members, selectedMemberId]);

  const filteredMembers = useMemo(() => {
    if (!searchTerm || selectedMemberId) return [];
    const term = searchTerm.toLowerCase();
    return members.filter(m => 
      m.gender === 'FEMALE' && // Must be a woman
      m.community === 'PATEL' && // Must be from Patel community
      (m.fullName.toLowerCase().includes(term) || m.registrationNumber.toLowerCase().includes(term))
    ).slice(0, 5);
  }, [members, searchTerm, selectedMemberId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return alert('પહેલા પાત્ર સભ્ય શોધો અને પસંદ કરો.');

    const claimAmount = 10000000; // 1 Crore

    onClaim({
      id: `dikri-${Math.random().toString(36).substr(2, 9)}`,
      memberId: selectedMember.id,
      memberName: selectedMember.fullName,
      amount: claimAmount,
      date: new Date().toISOString(),
      category: 'DIKRI_YOJNA',
      subCategory: '૧ કરોડ સહાય (પઠાન દીકરી યોજના)',
      message: `પતિ: ${formData.husbandName}, પત્નીનો અભ્યાસ: ${formData.wifeEducation}, પતિનો અભ્યાસ: ${formData.husbandEducation}. સંયુક્ત સહાય ૧ કરોડ.`,
      type: 'WITHDRAWAL' // It's money given OUT to the member
    });

    alert('અભિનંદન! ૧ કરોડની યોજનાનું ફોર્મ સફળતાપૂર્વક ભરાઈ ગયું છે અને તમને ૧ કરોડ રૂપિયા મળેલ છે.');
  };

  return (
    <div className="compact-container animate-fadeIn pb-20">
      <div className="flex items-center justify-between mb-6">
        <button onClick={onCancel} className="text-slate-500 font-bold hover:text-emerald-700 flex items-center transition text-xs"><i className="fas fa-chevron-left mr-1.5"></i> પાછા</button>
        <h2 className="text-lg font-bold text-amber-700 italic">પઠાન દીકરી યોજના (૧ કરોડ સહાય ફોર્મ)</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="space-y-6">
          {/* Member Search */}
          <div className="bg-white p-6 rounded-2xl ios-shadow border border-amber-100">
            <h3 className="text-sm font-bold text-slate-800 mb-4 flex items-center">
              <i className="fas fa-search-heart mr-2 text-amber-600"></i> ૧. સભ્યની શોધખોળ (પટેલ દીકરી)
            </h3>
            <div className="relative">
              <input 
                value={searchTerm} 
                onChange={(e) => {setSearchTerm(e.target.value); if(!e.target.value) setSelectedMemberId('');}} 
                placeholder="સભ્યનું નામ કે રજિસ્ટર નંબર..." 
                className="w-full px-4 py-3 border-2 border-slate-100 rounded-xl outline-none focus:border-amber-400 transition font-bold text-sm"
              />
              {filteredMembers.length > 0 && !selectedMemberId && (
                <div className="absolute z-50 w-full mt-2 bg-white border border-amber-100 rounded-xl shadow-2xl overflow-hidden glass">
                  {filteredMembers.map(m => (
                    <div key={m.id} onClick={() => {setSelectedMemberId(m.id); setSearchTerm(m.fullName);}} className="p-4 hover:bg-amber-50 cursor-pointer border-b last:border-0 flex items-center space-x-4">
                      <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center text-amber-600 font-bold">
                        {m.fullName.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-xs">{m.fullName}</p>
                        <p className="text-[9px] text-slate-400 font-bold uppercase">{m.registrationNumber} • {m.city}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            {selectedMember && (
              <div className="mt-4 p-4 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center space-x-4 animate-fadeIn">
                 <div className="w-12 h-12 rounded-lg overflow-hidden bg-white shadow-sm">
                    {selectedMember.photo ? <img src={selectedMember.photo} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-emerald-300"><i className="fas fa-user"></i></div>}
                 </div>
                 <div>
                    <p className="text-xs font-bold text-emerald-800">{selectedMember.fullName}</p>
                    <p className="text-[10px] text-emerald-600 font-bold">પાત્ર સભ્ય (પટેલ સમાજ સ્ત્રી)</p>
                 </div>
                 <i className="fas fa-check-circle text-emerald-500 ml-auto"></i>
              </div>
            )}
            {!selectedMember && searchTerm && filteredMembers.length === 0 && (
              <p className="mt-2 text-[10px] text-rose-500 font-bold italic">કોઈ પાત્ર સભ્ય મળ્યા નથી. (માત્ર પટેલ સમાજની સ્ત્રી સભ્ય જ આ યોજના માટે પાત્ર છે)</p>
            )}
          </div>

          {/* Details Form */}
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl ios-shadow border border-amber-100 space-y-4">
            <h3 className="text-sm font-bold text-slate-800 mb-2 flex items-center">
              <i className="fas fa-file-contract mr-2 text-amber-600"></i> ૨. દંપતીની વિગતો દાખલ કરો
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">પત્ની (સભ્ય) ની વિગત</label>
                <input required name="wifeAge" value={formData.wifeAge} onChange={handleChange} placeholder="પત્નીની ઉંમર *" type="number" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                <input required name="wifeEducation" value={formData.wifeEducation} onChange={handleChange} placeholder="પત્નીનો અભ્યાસ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                <input required name="wifeIncome" value={formData.wifeIncome} onChange={handleChange} placeholder="પત્નીની વાર્ષિક આવક *" type="number" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold text-emerald-700" />
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">પતિ (મુસ્લિમ છોકરો) ની વિગત</label>
                <input required name="husbandName" value={formData.husbandName} onChange={handleChange} placeholder="પતિનું પૂરૂ નામ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold" />
                <input required name="husbandAge" value={formData.husbandAge} onChange={handleChange} placeholder="પતિની ઉંમર *" type="number" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                <input required name="husbandEducation" value={formData.husbandEducation} onChange={handleChange} placeholder="પતિનો અભ્યાસ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                <input required name="husbandIncome" value={formData.husbandIncome} onChange={handleChange} placeholder="પતિની વાર્ષિક આવક *" type="number" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold text-emerald-700" />
              </div>
            </div>

            <div className="pt-4">
               <button 
                type="submit" 
                disabled={!selectedMember}
                className={`w-full py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl transition transform active:scale-95 ${selectedMember ? 'bg-gradient-to-r from-amber-500 to-amber-700 text-white hover:from-amber-600 hover:to-amber-800' : 'bg-slate-200 text-slate-400 cursor-not-allowed'}`}
               >
                 યોજના સબમિટ કરો (૧ કરોડ સહાય)
               </button>
            </div>
          </form>
        </div>

        {/* Real-time Notification Side */}
        <div className="space-y-6">
          <div className="bg-slate-900 rounded-[2rem] p-8 text-white ios-shadow border-t-8 border-amber-500 relative overflow-hidden h-full flex flex-col justify-center">
            <div className="relative z-10 space-y-6">
              <div className="flex items-center space-x-4">
                <div className="w-14 h-14 bg-amber-500 rounded-2xl flex items-center justify-center text-2xl shadow-lg animate-bounce">
                  <i className="fas fa-crown"></i>
                </div>
                <div>
                  <h4 className="text-xl font-bold italic text-amber-400">લાઈવ સ્કીમ નોટિફાય</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">તમારી લાયકાત અહીં તપાસો</p>
                </div>
              </div>

              <div className="space-y-4 pt-6">
                <div className={`p-5 rounded-2xl border-2 transition duration-500 ${selectedMember ? 'bg-emerald-500/10 border-emerald-500 text-emerald-100' : 'bg-white/5 border-white/10 text-white/40'}`}>
                  <p className="text-xs font-bold flex items-center">
                    <i className={`fas ${selectedMember ? 'fa-check-circle' : 'fa-circle'} mr-3 text-lg`}></i>
                    પટેલ સમાજની રજિસ્ટર્ડ દીકરી હોવી જોઈએ.
                  </p>
                </div>
                <div className={`p-5 rounded-2xl border-2 transition duration-500 ${formData.husbandName && formData.husbandAge ? 'bg-emerald-500/10 border-emerald-500 text-emerald-100' : 'bg-white/5 border-white/10 text-white/40'}`}>
                  <p className="text-xs font-bold flex items-center">
                    <i className={`fas ${formData.husbandName ? 'fa-check-circle' : 'fa-circle'} mr-3 text-lg`}></i>
                    મુસ્લિમ છોકરા જોડે લગ્ન કરેલા હોવા જોઈએ.
                  </p>
                </div>
                <div className={`p-5 rounded-2xl border-2 transition duration-500 ${formData.wifeEducation && formData.husbandEducation ? 'bg-emerald-500/10 border-emerald-500 text-emerald-100' : 'bg-white/5 border-white/10 text-white/40'}`}>
                  <p className="text-xs font-bold flex items-center">
                    <i className={`fas ${formData.wifeEducation && formData.husbandEducation ? 'fa-check-circle' : 'fa-circle'} mr-3 text-lg`}></i>
                    બંનેનો અભ્યાસ પૂરો હોવો જોઈએ.
                  </p>
                </div>
              </div>

              {selectedMember && formData.husbandName && (
                <div className="bg-amber-500 p-6 rounded-3xl mt-8 animate-pulse shadow-[0_0_40px_rgba(245,158,11,0.3)]">
                  <p className="text-slate-900 font-black text-center text-lg italic">
                    "તમને ૧ કરોડની યોજનામાં ૧ કરોડ રૂપિયા મળેલ છે."
                  </p>
                </div>
              )}
            </div>
            <div className="absolute top-[-50px] left-[-50px] w-64 h-64 bg-amber-500/10 rounded-full blur-[100px]"></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DikriYojnaForm;
