
import React from 'react';

interface HeaderProps {
  currentView: string;
  setView: (view: any) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  return (
    <header className="bg-emerald-800 text-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex flex-col md:flex-row justify-between items-center">
        <div 
          className="flex items-center space-x-3 cursor-pointer mb-3 md:mb-0"
          onClick={() => setView('HOME')}
        >
          <div className="bg-white p-1.5 rounded-full">
            <i className="fas fa-hand-holding-heart text-emerald-800 text-xl"></i>
          </div>
          <div>
            <h1 className="text-lg font-bold leading-tight">પઠાન સમાજ ચેરિટેબલ ટ્રસ્ટ</h1>
            <p className="text-[10px] text-emerald-200 font-semibold uppercase tracking-wider">મુસ્લિમ સ્વામિનારાયણ એકતા સમાજ</p>
          </div>
        </div>

        <nav className="flex flex-wrap justify-center gap-1.5 md:gap-4">
          <button 
            onClick={() => setView('HOME')}
            className={`px-3 py-1.5 rounded-xl text-xs transition ${currentView === 'HOME' ? 'bg-emerald-700 font-bold' : 'hover:bg-emerald-700/50'}`}
          >
            <i className="fas fa-home mr-1.5"></i> હોમ
          </button>
          <button 
            onClick={() => setView('REGISTER')}
            className={`px-3 py-1.5 rounded-xl text-xs transition ${currentView === 'REGISTER' ? 'bg-emerald-700 font-bold' : 'hover:bg-emerald-700/50'}`}
          >
            <i className="fas fa-user-plus mr-1.5"></i> નવું રજિસ્ટ્રેશન
          </button>
          <button 
            onClick={() => setView('DIRECTORY')}
            className={`px-3 py-1.5 rounded-xl text-xs transition ${currentView === 'DIRECTORY' ? 'bg-emerald-700 font-bold' : 'hover:bg-emerald-700/50'}`}
          >
            <i className="fas fa-users mr-1.5"></i> સભ્યોની યાદી
          </button>
          <button 
            onClick={() => setView('FUND')}
            className={`px-3 py-1.5 rounded-xl text-xs transition ${currentView === 'FUND' ? 'bg-emerald-700 font-bold' : 'hover:bg-emerald-700/50'}`}
          >
            <i className="fas fa-donate mr-1.5"></i> ફંડ
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;
