
import React, { useState, useMemo, useEffect } from 'react';
import { Member, Donation, FundMainCategory } from '../types';
import { numberToGujaratiWords, formatCurrency } from '../utils/gujaratiNumbers';

interface FundManagementProps {
  members: Member[];
  donations: Donation[];
  onDonate: (donation: Donation) => void;
  onViewMember: (id: string) => void;
}

const FundManagement: React.FC<FundManagementProps> = ({ members, donations, onDonate, onViewMember }) => {
  const [mode, setMode] = useState<'DEPOSIT' | 'WITHDRAWAL'>('DEPOSIT');
  const [searchTerm, setSearchTerm] = useState('');
  const [historySearchTerm, setHistorySearchTerm] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState('');
  const [category, setCategory] = useState<FundMainCategory>('GENERAL');
  const [subCategory, setSubCategory] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [selectedSchemeNumbers, setSelectedSchemeNumbers] = useState<number[]>([]);
  
  // Inner mode for withdrawal: Withdrawal vs Repayment (Jama)
  const [withdrawalTxType, setWithdrawalTxType] = useState<'WITHDRAWAL' | 'DEPOSIT'>('WITHDRAWAL');

  const selectedMember = useMemo(() => members.find(m => m.id === selectedMemberId), [members, selectedMemberId]);

  // Toggle selection for scheme numbers
  const toggleSchemeNumber = (num: number) => {
    setSelectedSchemeNumbers(prev => 
      prev.includes(num) ? prev.filter(n => n !== num) : [...prev, num]
    );
  };

  // English/Gujarati combined search
  const filteredMembersForSelect = useMemo(() => {
    if (!searchTerm || selectedMemberId) return [];
    const term = searchTerm.toLowerCase();
    return members.filter(m => 
      m.fullName.toLowerCase().includes(term) || 
      m.registrationNumber.toLowerCase().includes(term) ||
      m.city.toLowerCase().includes(term) ||
      m.subCaste.toLowerCase().includes(term)
    ).slice(0, 5);
  }, [members, searchTerm, selectedMemberId]);

  const subCategories: Record<FundMainCategory, string[]> = {
    'SNEHMILAN': ['જમણવાર દાતા', 'ઇનામવિત્રણ દાતા', 'અભ્યાસ દાતા', 'ચોપડા વિતરણ દાતા', 'સહાય યોજના', 'ધંધાકીય યોજના'],
    'LAGAN': ['મહિલા સહાય (૨૦ લાખ યોજના)', 'ક્ર્યાવર દાતા', 'જમણવાર દાતા'],
    'WOMEN_ASSISTANCE': ['મહિલા સહાય (૨૦ લાખ યોજના)'],
    'PATHAN_FUND': ['દૈનિક ફંડ', 'માસિક ફંડ', 'જનરલ ફંડ'],
    'GENERAL': ['અબ્દુલજી દલાલી'],
    'WITHDRAWAL': ['તબીબી સહાય', 'શિક્ષણ સહાય', 'લગ્ન સહાય', 'અકસ્માત સહાય', 'ધંધાકીય લોન', 'અન્ય ઉપાડ'],
    'DIKRI_YOJNA': ['૧ કરોડ સહાય (પઠાન દીકરી યોજના)']
  };

  useEffect(() => {
    const currentSubCats = subCategories[mode === 'WITHDRAWAL' ? 'WITHDRAWAL' : category];
    if (currentSubCats && currentSubCats.length > 0) {
      setSubCategory(currentSubCats[0]);
    }
  }, [mode, category]);

  useEffect(() => {
    if (subCategory === 'મહિલા સહાય (૨૦ લાખ યોજના)') {
      const total = selectedSchemeNumbers.length * 2000000;
      setAmount(total > 0 ? total.toString() : '');
    }
  }, [subCategory, selectedSchemeNumbers]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMember) return alert('સભ્ય પસંદ કરો');

    const principal = parseFloat(amount);
    if (isNaN(principal) || principal <= 0) return alert('યોગ્ય રકમ દાખલ કરો');

    let finalSubCat = subCategory;
    let finalMessage = message;

    if (subCategory === 'મહિલા સહાય (૨૦ લાખ યોજના)') {
      if (selectedSchemeNumbers.length === 0) return alert('કૃપા કરીને ઓછામાં ઓછો એક યોજના નંબર પસંદ કરો');
      finalSubCat = `મહિલા સહાય (કુલ ${selectedSchemeNumbers.length} નંબર)`;
      finalMessage = `પસંદ કરેલ નંબર: ${selectedSchemeNumbers.sort((a,b)=>a-b).join(', ')}. ${message}`;
    }

    onDonate({
      id: Math.random().toString(36).substr(2, 9),
      memberId: selectedMember.id,
      memberName: selectedMember.fullName,
      amount: principal,
      date: new Date().toISOString(),
      category: mode === 'WITHDRAWAL' ? 'WITHDRAWAL' : category,
      subCategory: mode === 'WITHDRAWAL' ? `${finalSubCat} (${withdrawalTxType === 'WITHDRAWAL' ? 'ઉપાડ' : 'જમા'})` : finalSubCat,
      message: finalMessage,
      type: mode === 'WITHDRAWAL' ? withdrawalTxType : 'DEPOSIT'
    });

    setAmount(''); setMessage(''); setSelectedMemberId(''); setSearchTerm(''); setCategory('GENERAL'); setSelectedSchemeNumbers([]);
    alert('માહિતી સફળતાપૂર્વક સેવ થઈ ગઈ છે!');
  };

  const handleModeSwitch = (newMode: 'DEPOSIT' | 'WITHDRAWAL') => {
    setMode(newMode);
    setAmount('');
    setMessage('');
    setSelectedSchemeNumbers([]);
    if (newMode === 'DEPOSIT') setCategory('GENERAL');
    else setCategory('WITHDRAWAL');
  };

  const filteredHistory = useMemo(() => {
    if (!historySearchTerm) return donations;
    const term = historySearchTerm.toLowerCase();
    return donations.filter(d => 
      d.memberName.toLowerCase().includes(term) || 
      d.category.toLowerCase().includes(term) ||
      d.subCategory?.toLowerCase().includes(term)
    );
  }, [donations, historySearchTerm]);

  const totalDepositValue = donations.filter(d => d.type === 'DEPOSIT').reduce((a, c) => a + c.amount, 0);
  const totalWithdrawalValue = donations.filter(d => d.type === 'WITHDRAWAL' || d.category === 'DIKRI_YOJNA').reduce((a, c) => a + c.amount, 0);
  const netBalance = totalDepositValue - totalWithdrawalValue;

  return (
    <div className="space-y-6 animate-fadeIn compact-container">
      {/* Trust Balance Summary Header */}
      <div className="bg-slate-900 rounded-[1.5rem] p-6 md:p-10 text-white ios-shadow flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-xl font-bold mb-1 italic">ટ્રસ્ટનો કુલ હિસાબ</h2>
          <div className="flex space-x-4 opacity-70">
            <p className="text-emerald-400 text-[11px] font-semibold">કુલ જમા: ₹{formatCurrency(totalDepositValue)}</p>
            <p className="text-rose-400 text-[11px] font-semibold">કુલ આપેલ સહાય: ₹{formatCurrency(totalWithdrawalValue)}</p>
          </div>
        </div>
        <div className="text-center md:text-right relative z-10">
          <h3 className="text-4xl md:text-5xl font-bold tabular-nums text-emerald-400">₹{formatCurrency(netBalance)}</h3>
          <p className="text-emerald-300 font-semibold italic mt-1 text-[11px]">{numberToGujaratiWords(netBalance)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1">
          <div className="bg-white rounded-[1.5rem] ios-shadow border border-slate-100 overflow-hidden sticky top-20">
            <div className="flex p-1 bg-slate-100 m-4 rounded-xl">
              <button type="button" onClick={() => handleModeSwitch('DEPOSIT')} className={`flex-1 py-2 rounded-lg font-bold text-xs transition ${mode === 'DEPOSIT' ? 'bg-emerald-700 text-white shadow-sm' : 'text-slate-500 hover:text-emerald-600'}`}>સભ્ય ભરે (+)</button>
              <button type="button" onClick={() => handleModeSwitch('WITHDRAWAL')} className={`flex-1 py-2 rounded-lg font-bold text-xs transition ${mode === 'WITHDRAWAL' ? 'bg-rose-700 text-white shadow-sm' : 'text-slate-500 hover:text-rose-600'}`}>સભ્યને આપો (-)</button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 pt-0 space-y-4">
              <div className="relative">
                <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">સભ્ય પસંદ કરો *</label>
                <div className="relative">
                  <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 text-xs"></i>
                  <input value={searchTerm} onChange={(e) => {setSearchTerm(e.target.value); if(!e.target.value) setSelectedMemberId('');}} placeholder="નામ કે નંબર દ્વારા શોધો..." className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl outline-none font-semibold focus:ring-1 focus:ring-emerald-500 transition text-sm" />
                </div>
                {searchTerm && !selectedMemberId && filteredMembersForSelect.length > 0 && (
                  <div className="absolute z-50 w-full mt-1 bg-white border border-slate-200 rounded-xl shadow-xl overflow-hidden glass">
                    {filteredMembersForSelect.map(m => (
                      <div key={m.id} onClick={() => {setSelectedMemberId(m.id); setSearchTerm(m.fullName);}} className="px-4 py-3 hover:bg-emerald-50 cursor-pointer border-b last:border-0 flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full overflow-hidden bg-slate-200">
                          {m.photo ? <img src={m.photo} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center text-slate-400"><i className="fas fa-user text-[10px]"></i></div>}
                        </div>
                        <span className="font-bold text-slate-800 text-xs">{m.fullName}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {mode === 'DEPOSIT' && (
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">ફંડ પ્રકાર *</label>
                  <select value={category} onChange={(e) => setCategory(e.target.value as FundMainCategory)} className="w-full px-3.5 py-2 border border-slate-200 rounded-xl font-bold text-slate-700 text-xs bg-slate-50">
                    <option value="LAGAN">લગન ફંડ</option>
                    <option value="GENERAL">સામાન્ય ફાળો</option>
                    <option value="PATHAN_FUND">પઠાન ફંડ</option>
                  </select>
                </div>
              )}

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">વિગત *</label>
                <select value={subCategory} onChange={(e) => setSubCategory(e.target.value)} className="w-full px-3.5 py-2 border border-slate-200 rounded-xl font-bold text-xs">
                  {subCategories[mode === 'WITHDRAWAL' ? 'WITHDRAWAL' : category].map(sc => (
                    <option key={sc} value={sc}>{sc}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-bold text-slate-400 uppercase mb-1 block">રકમ (₹) *</label>
                <input required type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0.00" className="w-full px-3.5 py-2 border border-slate-200 rounded-xl font-bold text-base outline-none focus:ring-1 focus:ring-emerald-500" />
                {amount && <p className="text-[10px] font-bold text-emerald-600 mt-1 italic">{numberToGujaratiWords(parseFloat(amount))}</p>}
              </div>

              <button type="submit" className={`w-full text-white font-bold py-3 rounded-xl shadow-md transition active:scale-95 text-xs uppercase ${mode === 'DEPOSIT' ? 'bg-emerald-700' : 'bg-rose-700'}`}>માહિતી સેવ કરો</button>
            </form>
          </div>
        </div>

        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-[1.5rem] ios-shadow border border-slate-100 overflow-hidden min-h-[600px]">
            <div className="p-6 border-b bg-slate-50/50">
               <h3 className="text-lg font-bold italic">વ્યવહાર હિસ્ટ્રી (સભ્યોના ખિસ્સા મુજબ)</h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 text-[9px] uppercase font-bold text-slate-400">
                  <tr>
                    <th className="px-6 py-3">સભ્ય</th>
                    <th className="px-6 py-3">વિગત</th>
                    <th className="px-6 py-3 text-right">સ્થિતિ (ખિસ્સું)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-xs">
                  {filteredHistory.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(d => {
                    const isMemberReceiving = d.type === 'WITHDRAWAL' || d.category === 'DIKRI_YOJNA';
                    return (
                      <tr key={d.id} className="hover:bg-slate-50 cursor-pointer" onClick={() => onViewMember(d.memberId)}>
                        <td className="px-6 py-4">
                          <span className="font-bold text-slate-800">{d.memberName}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-[10px] font-bold uppercase text-slate-500">{d.subCategory || d.category}</span>
                        </td>
                        <td className={`px-6 py-4 text-right font-bold tabular-nums ${isMemberReceiving ? 'text-emerald-700' : 'text-rose-700'}`}>
                          {isMemberReceiving ? '+' : '-'}₹{formatCurrency(d.amount)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FundManagement;
