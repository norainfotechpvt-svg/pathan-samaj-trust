
import React, { useState, useRef, useEffect } from 'react';
import { Member, Community, OccupationType, MaritalStatus, Gender } from '../types';
import { REGISTRATION_FEE, MUSLIM_MALE_REGISTRATION_FEE } from '../constants';
import { numberToGujaratiWords, formatCurrency } from '../utils/gujaratiNumbers';

interface RegistrationFormProps {
  onSubmit: (member: Member) => void;
  initialData?: Member;
  isEditing?: boolean;
  onCancel?: () => void;
}

const RegistrationForm: React.FC<RegistrationFormProps> = ({ onSubmit, initialData, isEditing, onCancel }) => {
  const [formData, setFormData] = useState({
    gender: (initialData?.gender || 'MALE') as Gender,
    fullName: initialData?.fullName || '',
    wifeName: initialData?.maritalStatus === 'MARRIED' ? (initialData.fullName.split(' + ')[0] || '') : '',
    photo: initialData?.photo || '',
    fatherName: initialData?.fatherName || '',
    husbandName: initialData?.husbandName || '',
    maritalStatus: (initialData?.maritalStatus || 'UNMARRIED') as MaritalStatus,
    useHusbandSuffix: initialData?.useHusbandSuffix ?? true,
    age: initialData?.age.toString() || '',
    wifeAge: initialData?.wifeAge?.toString() || '',
    husbandAge: initialData?.husbandAge?.toString() || '',
    city: initialData?.city || '',
    community: (initialData?.community || 'PATEL') as Community,
    subCaste: initialData?.subCaste || 'LEUVA',
    womanCaste: initialData?.womanCaste || '',
    husbandCaste: initialData?.husbandCaste || '',
    education: initialData?.education || '',
    wifeEducation: initialData?.wifeEducation || '',
    occupationType: (initialData?.occupationType || 'JOB') as OccupationType,
    wifeOccupation: (initialData?.wifeOccupation || 'GHARKAM') as OccupationType,
    occupationDetails: initialData?.occupationDetails || '',
    annualIncome: initialData?.annualIncome.toString() || '',
    recurringType: initialData?.recurringConfig?.type || 'NONE',
    recurringEnabled: initialData?.recurringConfig?.enabled || false,
    isRakhel: initialData?.isRakhel || false,
    rakhelOfName: initialData?.rakhelDetails?.ofWhoseName || '',
    rakhelYears: initialData?.rakhelDetails?.years.toString() || '',
  });

  const [isPaying, setIsPaying] = useState(false);
  const [payStep, setPayStep] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target as HTMLInputElement;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setFormData(prev => ({ ...prev, [name]: val }));
  };

  const currentRegFee = (formData.gender === 'MALE' && formData.community === 'MUSLIM') 
    ? MUSLIM_MALE_REGISTRATION_FEE 
    : REGISTRATION_FEE;

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setFormData(prev => ({ ...prev, photo: reader.result as string }));
      reader.readAsDataURL(file);
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Combine names based on preference
    let finalFullName = formData.fullName;
    if (formData.maritalStatus === 'MARRIED') {
      const baseName = `${formData.wifeName} + ${formData.husbandName}`;
      finalFullName = formData.useHusbandSuffix ? `${baseName} (પત્ની + પતિ)` : baseName;
    }

    const memberData: any = {
      gender: formData.gender,
      fullName: finalFullName,
      photo: formData.photo,
      fatherName: formData.fatherName,
      husbandName: formData.maritalStatus === 'MARRIED' ? formData.husbandName : '',
      maritalStatus: formData.maritalStatus,
      useHusbandSuffix: formData.useHusbandSuffix,
      nameSuffixPreference: formData.maritalStatus === 'MARRIED' ? (formData.useHusbandSuffix ? 'HUSBAND' : 'NONE') : 'FATHER',
      age: formData.maritalStatus === 'UNMARRIED' ? parseInt(formData.age) : 0,
      wifeAge: formData.maritalStatus === 'MARRIED' ? parseInt(formData.wifeAge) : undefined,
      husbandAge: formData.maritalStatus === 'MARRIED' ? parseInt(formData.husbandAge) : undefined,
      city: formData.city,
      community: formData.community,
      subCaste: formData.subCaste,
      womanCaste: formData.maritalStatus === 'MARRIED' ? formData.womanCaste : '',
      husbandCaste: formData.maritalStatus === 'MARRIED' ? formData.husbandCaste : '',
      education: (formData.gender === 'MALE' && formData.community === 'MUSLIM') ? undefined : formData.education,
      wifeEducation: formData.maritalStatus === 'MARRIED' ? formData.wifeEducation : '',
      occupationType: formData.occupationType,
      wifeOccupation: formData.maritalStatus === 'MARRIED' ? formData.wifeOccupation : 'NONE',
      occupationDetails: formData.occupationDetails,
      annualIncome: parseFloat(formData.annualIncome) || 0,
      recurringConfig: {
        type: formData.recurringType,
        enabled: formData.recurringEnabled,
        amount: formData.recurringType === 'DAILY' ? 3000 : 20000
      },
      isRakhel: formData.isRakhel || formData.occupationType === 'RAKHEL' || formData.wifeOccupation === 'RAKHEL',
      rakhelDetails: (formData.isRakhel || formData.occupationType === 'RAKHEL' || formData.wifeOccupation === 'RAKHEL') ? {
        ofWhoseName: formData.rakhelOfName,
        years: parseInt(formData.rakhelYears) || 0
      } : undefined
    };

    if (isEditing) {
      onSubmit({ ...initialData!, ...memberData });
      return;
    }

    setIsPaying(true);
    setPayStep(1);
    setTimeout(() => {
      setPayStep(2);
      setTimeout(() => {
        onSubmit({
          ...memberData,
          id: Math.random().toString(36).substr(2, 9),
          registrationNumber: `TRUST-${Math.floor(100000 + Math.random() * 900000)}`,
          registrationFeePaid: true,
          registrationDate: new Date().toISOString(),
        });
      }, 1000);
    }, 1500);
  };

  const totalDue = currentRegFee + (formData.recurringEnabled ? (formData.recurringType === 'DAILY' ? 3000 : 20000) : 0);

  if (isPaying) {
    return (
      <div className="max-w-xs mx-auto bg-white rounded-2xl ios-shadow mt-12 text-center p-8 space-y-4 glass">
        <div className={`w-12 h-12 ${payStep === 1 ? 'border-4 border-emerald-100 border-t-emerald-600 animate-spin' : 'bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl'} rounded-full mx-auto`}>
          {payStep === 2 && <i className="fas fa-check"></i>}
        </div>
        <p className="text-lg font-bold text-slate-800">{payStep === 1 ? 'પેમેન્ટ પ્રોસેસ...' : 'સફળ રજિસ્ટ્રેશન!'}</p>
        <p className="text-[10px] text-slate-400 font-bold uppercase">રજિસ્ટ્રેશન ફી: ₹{formatCurrency(currentRegFee)}</p>
      </div>
    );
  }

  return (
    <div className="compact-container bg-white rounded-2xl ios-shadow border border-slate-100 overflow-hidden animate-fadeIn mb-10">
      <div className="bg-emerald-800 text-white p-6 md:p-8 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold italic">{isEditing ? 'વિગત સુધારો' : 'નવું રજિસ્ટ્રેશન'}</h2>
          <p className="text-emerald-100 text-[10px] uppercase font-bold tracking-widest mt-1">મુસ્લિમ સ્વામિનારાયણ એકતા સમાજ • રજિસ્ટ્રેશન ફી: ₹{formatCurrency(currentRegFee)}</p>
        </div>
        {isEditing && <button onClick={onCancel} className="bg-white/10 hover:bg-white/20 px-4 py-1.5 rounded-lg text-xs font-bold transition">કેન્સલ</button>}
      </div>

      <form onSubmit={handleRegister} className="p-6 md:p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Status & Gender Selection */}
          <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2 tracking-widest">લિંગ (Gender) *</label>
              <div className="flex bg-slate-100 p-1 rounded-xl max-w-sm">
                <button type="button" onClick={() => setFormData(p => ({...p, gender: 'MALE'}))} className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${formData.gender === 'MALE' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}>પુરુષ</button>
                <button type="button" onClick={() => setFormData(p => ({...p, gender: 'FEMALE'}))} className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${formData.gender === 'FEMALE' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}>સ્ત્રી</button>
              </div>
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-2 tracking-widest">લગ્ન સ્થિતિ *</label>
              <div className="flex bg-slate-100 p-1 rounded-xl max-w-sm">
                <button type="button" onClick={() => setFormData(p => ({...p, maritalStatus: 'UNMARRIED'}))} className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${formData.maritalStatus === 'UNMARRIED' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}>અપરિણીત</button>
                <button type="button" onClick={() => setFormData(p => ({...p, maritalStatus: 'MARRIED'}))} className={`flex-1 py-2 rounded-lg text-xs font-bold transition ${formData.maritalStatus === 'MARRIED' ? 'bg-white shadow-sm text-emerald-700' : 'text-slate-500'}`}>પરિણીત</button>
              </div>
            </div>
          </div>

          {/* Identity Section */}
          <div className="space-y-4">
            <h3 className="font-bold text-emerald-800 border-b border-emerald-50 pb-1 flex items-center text-sm italic">
              <i className="fas fa-id-card mr-2 text-emerald-600"></i> વ્યક્તિગત માહિતી
            </h3>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-4 p-3 bg-slate-50 rounded-xl border border-slate-100 group relative">
                <div className="relative w-14 h-14 flex-shrink-0">
                  {formData.photo ? <img src={formData.photo} className="w-full h-full object-cover rounded-lg" /> : <div className="w-full h-full bg-white rounded-lg flex items-center justify-center text-emerald-600 border border-slate-200"><i className="fas fa-camera text-xl"></i></div>}
                  <button type="button" onClick={() => fileInputRef.current?.click()} className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-lg transition text-white text-[8px] font-bold">બદલો</button>
                </div>
                <div className="text-[10px] text-slate-500">પ્રોફાઇલ ફોટો ઉમેરો <input type="file" ref={fileInputRef} onChange={handlePhotoChange} accept="image/*" className="hidden" /></div>
              </div>

              {formData.maritalStatus === 'MARRIED' ? (
                <>
                  <input required name="wifeName" value={formData.wifeName} onChange={handleChange} placeholder="પત્નીનું નામ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold" />
                  <div className="space-y-2">
                    <input required name="husbandName" value={formData.husbandName} onChange={handleChange} placeholder="પતિનું નામ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold" />
                    <div className="flex items-center space-x-2 px-1">
                      <input type="checkbox" id="suffix_check" name="useHusbandSuffix" checked={formData.useHusbandSuffix} onChange={handleChange} className="accent-emerald-600" />
                      <label htmlFor="suffix_check" className="text-[10px] font-bold text-slate-500">પતિનું નામ પાછળ લગાવવું છે?</label>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input required name="womanCaste" value={formData.womanCaste} onChange={handleChange} placeholder="પત્નીની જ્ઞાતિ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-[10px]" />
                    <input required name="husbandCaste" value={formData.husbandCaste} onChange={handleChange} placeholder="પતિની જ્ઞાતિ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-[10px]" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input required type="number" name="wifeAge" value={formData.wifeAge} onChange={handleChange} placeholder="પત્નીની ઉંમર *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                    <input required type="number" name="husbandAge" value={formData.husbandAge} onChange={handleChange} placeholder="પતિની ઉંમર *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                  </div>
                </>
              ) : (
                <>
                  <input required name="fullName" value={formData.fullName} onChange={handleChange} placeholder="સભ્યનું નામ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold" />
                  <input required name="fatherName" value={formData.fatherName} onChange={handleChange} placeholder="પિતાનું નામ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold" />
                  <input required type="number" name="age" value={formData.age} onChange={handleChange} placeholder="ઉંમર *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                </>
              )}
              
              <input required name="city" value={formData.city} onChange={handleChange} placeholder="શહેર / ગામ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
            </div>
          </div>

          {/* Occupation & Education Section */}
          <div className="space-y-4">
            <h3 className="font-bold text-emerald-800 border-b border-emerald-50 pb-1 flex items-center text-sm italic">
              <i className="fas fa-briefcase mr-2 text-emerald-600"></i> અભ્યાસ અને વ્યવસાય
            </h3>

            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <select name="community" value={formData.community} onChange={handleChange} className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-slate-50 text-[10px] font-bold">
                  <option value="PATEL">પટેલ સમાજ</option>
                  <option value="MUSLIM">મુસ્લિમ સમાજ</option>
                </select>
                {formData.community === 'PATEL' ? (
                  <select name="subCaste" value={formData.subCaste} onChange={handleChange} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-[10px] font-bold text-emerald-700">
                    <option value="LEUVA">લેઉવા પટેલ</option>
                    <option value="KADVA">કડવા પટેલ</option>
                  </select>
                ) : (
                  <input name="subCaste" value={formData.subCaste} onChange={handleChange} placeholder="મુસ્લિમ જ્ઞાતિ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                )}
              </div>

              {formData.maritalStatus === 'MARRIED' ? (
                <>
                  <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <p className="text-[10px] font-bold text-emerald-800">પત્નીની વિગત:</p>
                    <input name="wifeEducation" value={formData.wifeEducation} onChange={handleChange} placeholder="પત્નીનો અભ્યાસ *" className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-[10px]" />
                    <select name="wifeOccupation" value={formData.wifeOccupation} onChange={handleChange} className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-[10px] font-semibold">
                      <option value="GHARKAM">ઘરકામ</option>
                      <option value="JOB">જોબ</option>
                      <option value="BUSINESS">બિઝનેસ</option>
                      <option value="RAKHEL">વફાદાર રખેલ</option>
                    </select>
                  </div>
                  <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <p className="text-[10px] font-bold text-emerald-800">પતિની વિગત:</p>
                    {!(formData.gender === 'MALE' && formData.community === 'MUSLIM') && (
                      <input name="education" value={formData.education} onChange={handleChange} placeholder="પતિનો અભ્યાસ *" className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-[10px]" />
                    )}
                    <select name="occupationType" value={formData.occupationType} onChange={handleChange} className="w-full px-3 py-1.5 border border-slate-200 rounded-lg text-[10px] font-semibold">
                      <option value="JOB">જોબ</option>
                      <option value="BUSINESS">બિઝનેસ</option>
                      <option value="NETA">નેતા</option>
                      <option value="UMEDVAR">ઉમેદવાર</option>
                    </select>
                  </div>
                </>
              ) : (
                <>
                  {!(formData.gender === 'MALE' && formData.community === 'MUSLIM') && (
                    <input name="education" value={formData.education} onChange={handleChange} placeholder="અભ્યાસ *" className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs" />
                  )}
                  <select name="occupationType" value={formData.occupationType} onChange={handleChange} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-semibold">
                    <option value="JOB">જોબ</option>
                    <option value="BUSINESS">બિઝનેસ</option>
                    <option value="RAKHEL">રખેલ</option>
                    <option value="NONE">અન્ય</option>
                  </select>
                </>
              )}
              
              <div className="pt-1">
                <input required type="number" name="annualIncome" value={formData.annualIncome} onChange={handleChange} placeholder={formData.maritalStatus === 'MARRIED' ? "સંયુક્ત વર્ષની આવક *" : "વર્ષની આવક *"} className="w-full px-3 py-2 border border-slate-200 rounded-lg text-xs font-bold text-emerald-700" />
                {formData.annualIncome && !isNaN(parseFloat(formData.annualIncome)) && parseFloat(formData.annualIncome) > 0 && (
                  <p className="text-[10px] font-bold text-emerald-600 mt-1 italic animate-fadeIn">
                    <i className="fas fa-check-double mr-1.5"></i> {numberToGujaratiWords(parseFloat(formData.annualIncome))}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Rakhel Details Section */}
          {(formData.occupationType === 'RAKHEL' || formData.wifeOccupation === 'RAKHEL' || formData.isRakhel) && (
            <div className="md:col-span-2 bg-rose-50 p-4 rounded-xl border border-rose-100 space-y-3 animate-fadeIn">
              <h4 className="text-[10px] font-bold text-rose-800 uppercase tracking-widest">રખેલ વિગતો</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input name="rakhelOfName" value={formData.rakhelOfName} onChange={handleChange} placeholder="કોની રખેલ છે? (નામ) *" className="w-full px-3 py-2 border border-rose-200 rounded-lg text-xs" />
                <input type="number" name="rakhelYears" value={formData.rakhelYears} onChange={handleChange} placeholder="કેટલા વર્ષ થી? *" className="w-full px-3 py-2 border border-rose-200 rounded-lg text-xs" />
              </div>
            </div>
          )}

          {/* Payment & Recurring */}
          <div className="md:col-span-2 bg-slate-900 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between text-white ios-shadow gap-6">
            <div className="flex-grow space-y-2 text-center md:text-left">
              <div className="flex items-center space-x-2 cursor-pointer justify-center md:justify-start" onClick={() => setFormData(p => ({...p, recurringEnabled: !p.recurringEnabled}))}>
                <input type="checkbox" checked={formData.recurringEnabled} readOnly className="w-4 h-4 accent-emerald-500" />
                <label className="text-xs font-bold text-emerald-400">ઓટોમેટિક ફાળો ચાલુ કરો</label>
              </div>
              {formData.recurringEnabled && (
                <select name="recurringType" value={formData.recurringType} onChange={handleChange} className="bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-[10px] text-white">
                  <option value="DAILY">દૈનિક (₹3,000)</option>
                  <option value="MONTHLY">માસિક (₹20,000)</option>
                </select>
              )}
              <p className="text-[10px] text-slate-400 italic">કુલ ભરવાની રકમ: {numberToGujaratiWords(totalDue)}</p>
            </div>
            <div className="text-center md:text-right">
              <p className="text-xs font-bold text-emerald-400 mb-1">ફાઇનલ રજિસ્ટ્રેશન ફી</p>
              <h3 className="text-3xl font-bold">₹{formatCurrency(totalDue)}</h3>
              <button type="submit" className="mt-3 bg-emerald-600 hover:bg-emerald-700 px-8 py-2.5 rounded-xl text-xs font-bold shadow-lg transform active:scale-95 transition">પૂર્ણ કરો અને સેવ કરો</button>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default RegistrationForm;
