
import React from 'react';
import { Member, Donation } from '../types';
import { formatCurrency, numberToGujaratiWords } from '../utils/gujaratiNumbers';

interface MemberProfileProps {
  member: Member;
  donations: Donation[];
  onEdit: () => void;
  onBack: () => void;
}

const MemberProfile: React.FC<MemberProfileProps> = ({ member, donations, onEdit, onBack }) => {
  // Categorize based on member's wallet perspective
  const paidByMember = donations.filter(d => d.type === 'DEPOSIT');
  const receivedByMember = donations.filter(d => d.type === 'WITHDRAWAL' || d.category === 'DIKRI_YOJNA');

  const totalPaidOut = paidByMember.reduce((sum, d) => sum + d.amount, 0);
  const totalReceivedIn = receivedByMember.reduce((sum, d) => sum + d.amount, 0);
  
  // Final Wallet Balance: Received - Paid (Positive if Samaj gave more, Negative if Member paid more)
  const walletBalance = totalReceivedIn - totalPaidOut;

  return (
    <div className="compact-container space-y-4 animate-fadeIn">
      <div className="flex items-center justify-between">
         <button onClick={onBack} className="text-slate-500 font-bold hover:text-emerald-700 flex items-center transition text-xs"><i className="fas fa-chevron-left mr-1.5"></i> પાછા</button>
         <div className="flex space-x-2">
            <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase border ${member.community === 'PATEL' ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-emerald-50 text-emerald-700 border-emerald-100'}`}>
              {member.community === 'PATEL' ? '૧૦% વ્યાજ લાગુ' : 'વ્યાજ મુક્ત (૦%)'}
            </span>
            <button onClick={onEdit} className="bg-emerald-700 text-white px-5 py-1.5 rounded-lg font-bold hover:bg-emerald-800 transition text-[10px]">વિગત સુધારો</button>
         </div>
      </div>

      <div className="bg-white rounded-[1.5rem] ios-shadow overflow-hidden border border-slate-100">
        {/* Profile Header with Wallet Perspective Total */}
        <div className="bg-slate-900 p-6 md:p-8 text-white flex flex-col md:flex-row justify-between items-center gap-6 border-b-8 border-emerald-600 relative overflow-hidden">
           <div className="flex items-center space-x-6 relative z-10">
              <div className="w-20 h-20 bg-emerald-600 rounded-2xl flex items-center justify-center text-4xl font-bold overflow-hidden border-2 border-white/20 shadow-xl">
                {member.photo ? <img src={member.photo} className="w-full h-full object-cover" /> : <span>{member.fullName.charAt(0)}</span>}
              </div>
              <div>
                 <h2 className="text-2xl font-bold italic drop-shadow-sm">{member.fullName}</h2>
                 <p className="text-emerald-400 font-mono text-xs uppercase tracking-[0.2em] font-bold">{member.registrationNumber}</p>
                 <div className="flex items-center space-x-2 mt-1.5">
                   <span className="text-[10px] bg-white/10 px-2 py-0.5 rounded font-bold uppercase">{member.city}</span>
                   <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-bold uppercase border border-emerald-500/30">{member.subCaste}</span>
                 </div>
              </div>
           </div>
           
           {/* Wallet Status: Positive = Benefited from Trust, Negative = Paid to Trust */}
           <div className="text-center md:text-right relative z-10 bg-white/5 backdrop-blur-md p-4 rounded-2xl border border-white/10">
              <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-1">ચોખ્ખો બેનિફિટ / સંતુલન</p>
              <h3 className={`text-3xl md:text-4xl font-black tabular-nums ${walletBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {walletBalance < 0 ? '-' : '+'}₹{formatCurrency(Math.abs(walletBalance))}
              </h3>
              <p className="text-[9px] text-white/60 font-bold mt-1 italic">{numberToGujaratiWords(Math.abs(walletBalance))}</p>
           </div>
           
           <i className="fas fa-wallet absolute right-[-20px] bottom-[-20px] text-white opacity-[0.03] text-[12rem] pointer-events-none"></i>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4">
           {/* Detailed Information Sidebar */}
           <div className="p-6 bg-slate-50/50 border-r border-slate-100 space-y-6">
              
              <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-100">
                <h4 className="text-[10px] font-bold text-emerald-800 border-b border-emerald-50 pb-2 uppercase tracking-widest mb-3">પર્સનલ પ્રોફાઇલ</h4>
                
                <div className="space-y-4">
                  <div className="space-y-1">
                    <p className="text-[9px] text-slate-400 font-bold uppercase">વાર્ષિક આવક</p>
                    <p className="text-xs font-bold text-emerald-700">₹{formatCurrency(member.annualIncome)}</p>
                    <p className="text-[9px] text-slate-400 italic">{numberToGujaratiWords(member.annualIncome)}</p>
                  </div>
                  {member.maritalStatus === 'MARRIED' ? (
                    <>
                      <div className="space-y-1">
                        <p className="text-[9px] text-slate-400 font-bold uppercase">પત્ની / પતિ</p>
                        <p className="text-xs font-bold text-slate-800">{member.fullName}</p>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                         <div>
                           <p className="text-[8px] text-slate-400 font-bold">પત્ની ઉંમર</p>
                           <p className="text-[11px] font-bold">{member.wifeAge} વર્ષ</p>
                         </div>
                         <div>
                           <p className="text-[8px] text-slate-400 font-bold">પતિ ઉંમર</p>
                           <p className="text-[11px] font-bold">{member.husbandAge} વર્ષ</p>
                         </div>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="space-y-1">
                        <p className="text-[9px] text-slate-400 font-bold uppercase">પિતાનું નામ</p>
                        <p className="text-xs font-bold text-slate-800">{member.fatherName}</p>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div className="bg-emerald-900 rounded-xl p-4 text-white shadow-lg">
                 <h4 className="text-[9px] font-bold text-emerald-400 border-b border-emerald-800 pb-2 uppercase tracking-widest mb-3">હિસાબી સારાંશ</h4>
                 <div className="space-y-3">
                    <div className="flex justify-between items-center">
                       <span className="text-[10px] text-rose-300">તમે ભરેલ ફંડ (-):</span>
                       <span className="text-xs font-bold text-rose-300">-₹{formatCurrency(totalPaidOut)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                       <span className="text-[10px] text-emerald-300">સમાજની સહાય (+):</span>
                       <span className="text-xs font-bold text-emerald-300">+₹{formatCurrency(totalReceivedIn)}</span>
                    </div>
                    <div className="pt-2 border-t border-emerald-800 flex justify-between items-center">
                       <span className="text-[10px] font-bold">ચોખ્ખું બેલેન્સ:</span>
                       <span className={`text-sm font-black ${walletBalance >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                         {walletBalance < 0 ? '-' : '+'}₹{formatCurrency(Math.abs(walletBalance))}
                       </span>
                    </div>
                 </div>
              </div>
           </div>

           {/* Personal Passbook Ledger History with Member Sign Logic */}
           <div className="lg:col-span-3 p-6 md:p-8 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <h3 className="text-lg font-bold italic flex items-center">
                  <i className="fas fa-history mr-3 text-emerald-600"></i> પાસબુક (સભ્યની દૃષ્ટિએ)
                </h3>
              </div>
              
              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
                 {donations.length === 0 ? (
                   <div className="py-20 text-center text-slate-300 italic">કોઈ વ્યવહાર મળ્યા નથી.</div>
                 ) : (
                   donations.sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(d => {
                      const isGrant = d.type === 'WITHDRAWAL' || d.category === 'DIKRI_YOJNA';
                      return (
                        <div key={d.id} className={`p-4 bg-white border border-slate-100 rounded-2xl flex justify-between items-center shadow-sm hover:shadow-md transition group border-l-4 ${isGrant ? 'border-l-emerald-500 bg-emerald-50/10' : 'border-l-rose-500 bg-rose-50/10'}`}>
                           <div className="flex items-center space-x-4">
                              <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm shadow-inner transition ${isGrant ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}`}>
                                 <i className={`fas ${isGrant ? 'fa-plus-circle' : 'fa-minus-circle'}`}></i>
                              </div>
                              <div>
                                <div className="font-bold text-slate-800 text-xs md:text-sm">
                                  {d.subCategory || d.category}
                                </div>
                                <div className="flex items-center space-x-2 mt-0.5">
                                  <span className="text-[9px] text-slate-400 font-bold uppercase">{new Date(d.date).toLocaleDateString('gu-IN')}</span>
                                  <span className="text-[8px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500 font-bold uppercase">
                                    {isGrant ? 'પ્રાપ્ત થયેલ' : 'તમે આપેલ'}
                                  </span>
                                </div>
                              </div>
                           </div>
                           <div className="text-right">
                              <div className={`text-base md:text-lg font-black tabular-nums ${isGrant ? 'text-emerald-700' : 'text-rose-700'}`}>
                                 {isGrant ? '+' : '-'}₹{formatCurrency(d.amount)}
                              </div>
                           </div>
                        </div>
                      );
                   })
                 )}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default MemberProfile;
