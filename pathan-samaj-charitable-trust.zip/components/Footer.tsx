
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-white py-10 mt-10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6 text-sm">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <i className="fas fa-hand-holding-heart text-emerald-400 text-2xl"></i>
              <h2 className="text-lg font-bold">પઠાન સમાજ ચેરિટેબલ ટ્રસ્ટ</h2>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              અમે સમાજના દરેક વર્ગના વિકાસ માટે કાર્યરત છીએ. 
              તમારો ડેટા અહીં હંમેશા સુરક્ષિત અને ગોપનીય રહેશે.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-bold mb-4 text-emerald-400">સંપર્ક વિગતો</h3>
            <ul className="space-y-2 text-slate-400 text-xs">
              <li className="flex items-start space-x-2">
                <i className="fas fa-map-marker-alt mt-1"></i>
                <span>નવી દિલ્લી, જામા મસ્જિદ, ભારત.</span>
              </li>
              <li className="flex items-center space-x-2">
                <i className="fas fa-phone-alt"></i>
                <span>+91 98765 43210</span>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-bold mb-4 text-emerald-400">ઝડપી લિંક્સ</h3>
            <ul className="grid grid-cols-2 gap-2 text-slate-400 text-[11px]">
              <li className="hover:text-emerald-400 cursor-pointer">અમારા વિશે</li>
              <li className="hover:text-emerald-400 cursor-pointer">નિયમો</li>
              <li className="hover:text-emerald-400 cursor-pointer">સહાય</li>
              <li className="hover:text-emerald-400 cursor-pointer">ગોપનીયતા</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-800 pt-6 text-center text-slate-500 text-[10px]">
          <p>© {new Date().getFullYear()} પઠાન સમાજ ચેરિટેબલ ટ્રસ્ટ. મુસ્લિમ સ્વામિનારાયણ એકતા સમાજ.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
